﻿namespace Vehicles
{
    public abstract class Vehicle
    {
        public double FuelQuantity { get; set; }

        public double FuelConsumptionInLiters { get; set; }

        public abstract string Drive(double km);

        public abstract void Refuel(double liters);
    }
}
